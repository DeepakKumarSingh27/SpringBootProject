package org.jsp.userbootapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserBootAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserBootAppApplication.class, args);
	}

}
