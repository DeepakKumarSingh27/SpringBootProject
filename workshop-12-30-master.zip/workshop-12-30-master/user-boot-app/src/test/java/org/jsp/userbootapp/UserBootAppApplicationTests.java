package org.jsp.userbootapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserBootAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
